package preprocess_input;

import java.io.IOException;
import java.util.Arrays;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.OutputStreamWriter;
import java.util.HashSet;
import java.io.BufferedWriter;
import java.io.FileWriter;

import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;

import java.util.Collections;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.conf.Configured;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Counter;
import org.apache.hadoop.mapreduce.Counters;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.input.TextInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;
import org.apache.hadoop.mapreduce.lib.output.TextOutputFormat;
import org.apache.hadoop.util.Tool;
import org.apache.hadoop.util.ToolRunner;

public class assign2_stopwords extends Configured implements Tool {
	
	   public static enum NUMBER_OF_LINES_COUNTER { // add counter for number of lines
		   TOTAL_NUMBER_OF_LINES,
	      };
	
	
	public static void main(String[] args) throws Exception {
		System.out.println(Arrays.toString(args));
		int res = ToolRunner.run(new Configuration(), new assign2_stopwords(), args);	
		System.exit(res);
		   }

	@Override
	public int run(String[] args) throws Exception {
	      System.out.println(Arrays.toString(args));
	      Job job = new Job(getConf(), "assign2_stopwords");
	      job.setJarByClass(assign2_stopwords.class);
	      job.setOutputKeyClass(LongWritable.class);
		  job.setOutputValueClass(Text.class); 

	      job.setMapperClass(Map.class);
	      job.setReducerClass(Reduce.class);
	      job.setNumReduceTasks(1);

	      job.setInputFormatClass(TextInputFormat.class);
	      job.setOutputFormatClass(TextOutputFormat.class);
	      	      
	      FileInputFormat.addInputPath(job, new Path(args[0]));
	      FileOutputFormat.setOutputPath(job, new Path(args[1]));
	      job.getConfiguration().set("mapreduce.output.textoutputformat.separator", ";");
	      
	      FileSystem fs = FileSystem.newInstance(getConf());

	      if (fs.exists(new Path(args[1]))) {
				fs.delete(new Path(args[1]), true);
			}
	       
	      job.waitForCompletion(true);	
	      
	      
	   // counter of output records


			job.waitForCompletion(true);
			
			long counter = job.getCounters().findCounter(NUMBER_OF_LINES_COUNTER.TOTAL_NUMBER_OF_LINES)
					.getValue();
			Path outFile = new Path("TOTAL_NUMBER_OF_LINES.txt");
			BufferedWriter BufWri = new BufferedWriter(new OutputStreamWriter(
					fs.create(outFile, true)));
			BufWri.write(String.valueOf(counter));
			BufWri.close();
		
		
          return 0;
	}
	
	

///////////////////////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////// MAP ///////////////////////////////////////////////////////////////


	 public static class Map extends Mapper<LongWritable, Text, LongWritable, Text> {
		  
	      @Override
	      public void map(LongWritable key, Text value, Context context)
	              throws IOException, InterruptedException {
	    	
	    	 
	                    
	                // hashset that contains all stopwords
	                    HashSet<String> stopwords = new HashSet<String>();
	                    BufferedReader Reader = new BufferedReader(new FileReader(new File("/home/cloudera/workspace/preprocess_input/StopWords.csv")));
	                   String pattern;
	                   while ((pattern = Reader.readLine()) != null) {
	                      stopwords.add(pattern.trim().toLowerCase());

	                   } // store StopWords into stopwords hashset

	                   Reader.close(); // close Reader for avoiding 'too many open files' error
	                   
	                   
	                   
	                   
						Pattern pat_spe_char = Pattern.compile("\\W"); 
			        	// pat_spe_char takes into account all special characters
				    	 	                   

				    	 
				    	 
				    	 
	    	 for (String token: value.toString().split("\\s*\\b\\s*")) {
	        	 if (stopwords.contains(token.toLowerCase()) ||
	        	     pat_spe_char.matcher(token.toLowerCase()).find())  {
	    	             continue;
	    	             } // skip if stopword or special character detected 		 
	        	
	             context.write(key, new Text(token.toLowerCase()));
	         }
	      }
	   }

///////////////////////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////// REDUCE ///////////////////////////////////////////////////////////////

	   public static class Reduce extends Reducer<LongWritable, Text, LongWritable, Text> {
		      public void reduce(LongWritable key, Iterable<Text> values, Context context)
		              throws IOException, InterruptedException {

		    	  
		          HashMap<String, Integer> container = new HashMap<String, Integer>(); 
		          // define a container for pairs of string + integer
		          // it will correspond to <file name, number of occurrences of the key-word in the file>
		          
		          for (Text value : values) {
		          if (!container.containsKey(value.toString())) {
		         	 container.put(value.toString(),1);
		         	// if the value/file name is stored for the 1st time, set value at 1 
		          }else{
		         	
		         	 int count = container.get(value.toString()) + 1;
		         	 container.put(value.toString(), count);
		           // otherwise, if the value is already stored, increase the value by 1
		               }
		          }
		          
		          StringBuilder unsorted_word_set = new StringBuilder();
		          // in the value of the reducer output, the filenames are separated by commas and spaces
		          String separator1 = "";
		          for (String value : container.keySet()) {
		        	  unsorted_word_set.append(separator1);
		             separator1 = "; ";
		             unsorted_word_set.append(value + "#" + container.get(value));
		          } // for each word, add the number of occurences
		          				
					
		          context.getCounter(NUMBER_OF_LINES_COUNTER.TOTAL_NUMBER_OF_LINES).increment(1);
		          context.write(key, new Text(unsorted_word_set.toString())); // generate key-value pairs of reducer output
		          // unsorted_word_set.toString().replaceAll("#\\d+", "").replaceAll(";", "")     // if only words wanted, without numbers of occurences
		     
		      }
		   }
}